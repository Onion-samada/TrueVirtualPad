package com.padvirtuel.app

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.DashPathEffect
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Typeface
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import kotlin.math.abs
import kotlin.math.hypot

class PadView(
    ctx: Context,
    private val id: String,
    private val label: String,
    private val color: Int
) : View(ctx) {

    var editing = false
    var onButton: ((Boolean) -> Unit)? = null
    var onDir: ((Int, Int) -> Unit)? = null
    var onDrag: ((Float, Float) -> Unit)? = null

    private val isPad = id == "dpad"
    private var down = false
    private var dirX = 0
    private var dirY = 0
    private var offX = 0f
    private var offY = 0f
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()

    override fun onDraw(c: Canvas) {
        val cx = width / 2f
        val cy = height / 2f
        val r = minOf(width, height) / 2f - 8f
        val cr = Color.red(color)
        val cg = Color.green(color)
        val cb = Color.blue(color)

        p.pathEffect = null
        p.style = Paint.Style.FILL
        p.color = if (down && !isPad) Color.argb(150, cr, cg, cb) else Color.argb(95, 0, 0, 0)
        c.drawCircle(cx, cy, r, p)

        p.style = Paint.Style.STROKE
        p.strokeWidth = 4f
        p.color = if (isPad) Color.argb(110, 255, 255, 255) else Color.argb(230, cr, cg, cb)
        c.drawCircle(cx, cy, r, p)

        p.style = Paint.Style.FILL
        if (isPad) {
            for ((dx, dy) in listOf(0 to -1, 0 to 1, -1 to 0, 1 to 0)) {
                val active = (dx != 0 && dirX == dx) || (dy != 0 && dirY == dy)
                p.color = Color.argb(if (active) 245 else 120, 255, 255, 255)
                val tx = cx + dx * r * 0.78f
                val ty = cy + dy * r * 0.78f
                val bx = cx + dx * r * 0.42f
                val by = cy + dy * r * 0.42f
                val ox = -dy.toFloat()
                val oy = dx.toFloat()
                path.reset()
                path.moveTo(tx, ty)
                path.lineTo(bx + ox * r * 0.2f, by + oy * r * 0.2f)
                path.lineTo(bx - ox * r * 0.2f, by - oy * r * 0.2f)
                path.close()
                c.drawPath(path, p)
            }
        } else {
            p.color = color
            p.textAlign = Paint.Align.CENTER
            p.typeface = Typeface.DEFAULT_BOLD
            p.textSize = r * 0.9f
            c.drawText(label, cx, cy - (p.descent() + p.ascent()) / 2f, p)
        }

        if (editing) {
            p.style = Paint.Style.STROKE
            p.strokeWidth = 3f
            p.color = Color.WHITE
            p.pathEffect = DashPathEffect(floatArrayOf(14f, 10f), 0f)
            c.drawCircle(cx, cy, r + 4f, p)
        }
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (editing) {
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    val loc = IntArray(2)
                    getLocationOnScreen(loc)
                    offX = loc[0] + width / 2f - e.rawX
                    offY = loc[1] + height / 2f - e.rawY
                }
                MotionEvent.ACTION_MOVE -> onDrag?.invoke(e.rawX + offX, e.rawY + offY)
            }
            return true
        }
        if (isPad) {
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN, MotionEvent.ACTION_MOVE -> updateDir(e.x, e.y)
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> setDir(0, 0)
            }
        } else {
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    down = true
                    invalidate()
                    performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY)
                    onButton?.invoke(true)
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> releaseAll()
            }
        }
        return true
    }

    private fun updateDir(x: Float, y: Float) {
        val dx = x - width / 2f
        val dy = y - height / 2f
        var nx = 0
        var ny = 0
        if (hypot(dx, dy) > width / 2f * 0.25f) {
            if (abs(dx) > abs(dy) * 0.5f) nx = if (dx > 0) 1 else -1
            if (abs(dy) > abs(dx) * 0.5f) ny = if (dy > 0) 1 else -1
        }
        setDir(nx, ny)
    }

    private fun setDir(nx: Int, ny: Int) {
        if (nx == dirX && ny == dirY) return
        dirX = nx
        dirY = ny
        invalidate()
        onDir?.invoke(nx, ny)
    }

    fun releaseAll() {
        if (down) {
            down = false
            onButton?.invoke(false)
        }
        setDir(0, 0)
        invalidate()
    }
}
