package com.padvirtuel.app

import android.content.Context
import android.content.SharedPreferences

object Prefs {
    private var sp: SharedPreferences? = null
    private val s: SharedPreferences get() = sp!!

    val ids = listOf("dpad", "a", "b", "x", "y")
    val names = mapOf(
        "dpad" to "Croix directionnelle", "a" to "Bouton A", "b" to "Bouton B",
        "x" to "Bouton X", "y" to "Bouton Y"
    )
    private val defX = mapOf("dpad" to 0.14f, "a" to 0.87f, "b" to 0.935f, "x" to 0.805f, "y" to 0.87f)
    private val defY = mapOf("dpad" to 0.68f, "a" to 0.80f, "b" to 0.66f, "x" to 0.66f, "y" to 0.52f)

    fun init(c: Context) {
        if (sp == null) sp = c.applicationContext.getSharedPreferences("pad", Context.MODE_PRIVATE)
    }

    // Taille de base = fraction du petit côté de l'écran
    fun base(id: String) = if (id == "dpad") 0.46f else 0.19f

    fun x(id: String) = s.getFloat("$id.x", defX[id] ?: 0.5f)
    fun y(id: String) = s.getFloat("$id.y", defY[id] ?: 0.5f)
    fun setPos(id: String, x: Float, y: Float) =
        s.edit().putFloat("$id.x", x).putFloat("$id.y", y).apply()

    fun scale(id: String) = s.getFloat("$id.scale", 1f)
    fun setScale(id: String, v: Float) = s.edit().putFloat("$id.scale", v).apply()

    fun visible(id: String) = s.getBoolean("$id.visible", true)
    fun setVisible(id: String, v: Boolean) = s.edit().putBoolean("$id.visible", v).apply()

    var opacity: Float
        get() = s.getFloat("opacity", 0.85f)
        set(v) = s.edit().putFloat("opacity", v).apply()

    fun reset() = s.edit().clear().apply()
}
