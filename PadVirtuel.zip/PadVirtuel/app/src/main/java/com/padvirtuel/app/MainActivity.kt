package com.padvirtuel.app

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import rikka.shizuku.Shizuku

class MainActivity : Activity() {

    private val ui = Handler(Looper.getMainLooper())
    private val accent = 0xFF5EE08A.toInt()
    private val textColor = 0xFFE8EAF0.toInt()

    private lateinit var tvOverlay: TextView
    private lateinit var btnOverlay: Button
    private lateinit var tvShizuku: TextView
    private lateinit var btnShizuku: Button
    private lateinit var btnRun: Button
    private lateinit var btnEdit: Button
    private lateinit var tvLog: TextView

    private val loop = object : Runnable {
        override fun run() {
            refresh()
            ui.postDelayed(this, 1500)
        }
    }
    private val onBinder = Shizuku.OnBinderReceivedListener { runOnUiThread { refresh() } }
    private val onDead = Shizuku.OnBinderDeadListener { runOnUiThread { refresh() } }
    private val onPerm = Shizuku.OnRequestPermissionResultListener { _, _ -> runOnUiThread { refresh() } }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Prefs.init(this)
        setContentView(buildUi())
        Shizuku.addBinderReceivedListenerSticky(onBinder)
        Shizuku.addBinderDeadListener(onDead)
        Shizuku.addRequestPermissionResultListener(onPerm)
    }

    override fun onResume() {
        super.onResume()
        ui.post(loop)
    }

    override fun onPause() {
        ui.removeCallbacks(loop)
        super.onPause()
    }

    override fun onDestroy() {
        Shizuku.removeBinderReceivedListener(onBinder)
        Shizuku.removeBinderDeadListener(onDead)
        Shizuku.removeRequestPermissionResultListener(onPerm)
        super.onDestroy()
    }

    // ---------- UI ----------

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun label(t: String, size: Float = 15f, color: Int = textColor) = TextView(this).apply {
        text = t
        textSize = size
        setTextColor(color)
        setPadding(0, dp(6), 0, dp(4))
    }

    private fun btn(t: String, onClick: () -> Unit) = Button(this).apply {
        text = t
        isAllCaps = false
        setOnClickListener { onClick() }
    }

    private fun seek(min: Int, max: Int, init: Int, onChange: (Int) -> Unit) = SeekBar(this).apply {
        this.max = max - min
        progress = init - min
        setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                if (fromUser) onChange(p + min)
            }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
    }

    private fun buildUi(): ScrollView {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(28), dp(20), dp(28))
        }
        val scroll = ScrollView(this).apply {
            setBackgroundColor(0xFF14161C.toInt())
            addView(root, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        }

        root.addView(label("Pad Virtuel", 28f, accent))
        root.addView(label("Une manette tactile par-dessus ton jeu.", 14f, 0xFF9AA0B0.toInt()))

        root.addView(label("Autorisations", 18f, accent))
        tvOverlay = label("")
        root.addView(tvOverlay)
        btnOverlay = btn("Autoriser l'affichage par-dessus") {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        }
        root.addView(btnOverlay)
        tvShizuku = label("")
        root.addView(tvShizuku)
        btnShizuku = btn("") { shizukuAction() }
        root.addView(btnShizuku)

        root.addView(label("Manette", 18f, accent))
        btnRun = btn("") { toggleRun() }
        root.addView(btnRun)
        btnEdit = btn("") {
            val s = OverlayService.instance
            if (s == null) toast("Démarre d'abord la manette") else s.toggleEdit()
            refresh()
        }
        root.addView(btnEdit)

        root.addView(label("Réglages", 18f, accent))
        root.addView(label("Opacité"))
        root.addView(seek(20, 100, (Prefs.opacity * 100).toInt()) {
            Prefs.opacity = it / 100f
            OverlayService.instance?.relayoutAll()
        })
        for (id in Prefs.ids) {
            root.addView(label(Prefs.names[id] ?: id))
            root.addView(Switch(this).apply {
                text = "Visible"
                setTextColor(textColor)
                isChecked = Prefs.visible(id)
                setOnCheckedChangeListener { _, c ->
                    Prefs.setVisible(id, c)
                    OverlayService.instance?.relayoutAll()
                }
            })
            root.addView(seek(50, 200, (Prefs.scale(id) * 100).toInt()) {
                Prefs.setScale(id, it / 100f)
                OverlayService.instance?.relayoutAll()
            })
        }
        root.addView(btn("Tout réinitialiser") {
            Prefs.reset()
            OverlayService.instance?.relayoutAll()
            recreate()
        })

        root.addView(label("État", 18f, accent))
        tvLog = label("", 12f, 0xFF9AA0B0.toInt())
        root.addView(tvLog)
        return scroll
    }

    // ---------- Actions ----------

    private fun toast(t: String) = Toast.makeText(this, t, Toast.LENGTH_LONG).show()

    private fun shizukuAction() {
        if (!Shizuku.pingBinder()) {
            val i = packageManager.getLaunchIntentForPackage("moe.shizuku.privileged.api")
            if (i != null) startActivity(i) else toast("Installe l'app Shizuku d'abord")
        } else if (Shizuku.checkSelfPermission() != PackageManager.PERMISSION_GRANTED) {
            Shizuku.requestPermission(1)
        }
    }

    private fun toggleRun() {
        if (OverlayService.instance != null) {
            stopService(Intent(this, OverlayService::class.java))
        } else {
            if (!Settings.canDrawOverlays(this)) {
                toast("Autorise d'abord l'affichage par-dessus")
                return
            }
            if (Build.VERSION.SDK_INT >= 33 &&
                checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
            ) {
                requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 2)
            }
            OverlayService.start(this)
        }
        ui.postDelayed({ refresh() }, 500)
    }

    private fun refresh() {
        val overlayOk = Settings.canDrawOverlays(this)
        tvOverlay.text = "Affichage par-dessus : " + if (overlayOk) "✔ autorisé" else "✘ manquant"
        btnOverlay.isEnabled = !overlayOk

        val alive = try { Shizuku.pingBinder() } catch (e: Throwable) { false }
        val granted = alive && try {
            Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
        } catch (e: Throwable) { false }
        tvShizuku.text = "Shizuku : " + when {
            !alive -> "✘ non lancé"
            !granted -> "✘ autorisation requise"
            else -> "✔ prêt"
        }
        btnShizuku.text = when {
            !alive -> "Ouvrir Shizuku"
            !granted -> "Autoriser Shizuku"
            else -> "Shizuku OK"
        }
        btnShizuku.isEnabled = !granted

        val running = OverlayService.instance != null
        btnRun.text = if (running) "Arrêter la manette" else "Démarrer la manette"
        btnEdit.text = if (OverlayService.instance?.editing == true) "Terminer l'édition" else "Mode édition (déplacer les touches)"
        tvLog.text = "Manette : ${UinputPad.status}" + if (UinputPad.log.isNotEmpty()) "\n${UinputPad.log}" else ""
    }
}
