package com.padvirtuel.app

import android.content.pm.PackageManager
import rikka.shizuku.Shizuku
import java.io.OutputStream
import java.util.concurrent.Executors
import kotlin.concurrent.thread

/**
 * Crée une VRAIE manette virtuelle (via la commande système `uinput`, lancée avec les droits
 * "shell" grâce à Shizuku). Android la voit comme une manette branchée, donc Godot aussi.
 */
object UinputPad {
    @Volatile var status = "Arrêtée"
    @Volatile var log = ""

    private var proc: Process? = null
    private var out: OutputStream? = null
    private val ex = Executors.newSingleThreadExecutor()
    private val codes = mapOf("a" to 304, "b" to 305, "x" to 307, "y" to 308)

    fun ready(): Boolean = try {
        Shizuku.pingBinder() && Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
    } catch (e: Throwable) {
        false
    }

    fun start() {
        thread { begin(0) }
    }

    @Synchronized
    private fun begin(variant: Int) {
        stop()
        if (!ready()) {
            status = "Shizuku indisponible (lancé ? autorisé ?)"
            return
        }
        try {
            status = "Création de la manette…"
            log = ""
            val m = Shizuku::class.java.getDeclaredMethod(
                "newProcess", Array<String>::class.java, Array<String>::class.java, String::class.java
            )
            m.isAccessible = true
            val p = m.invoke(null, arrayOf("sh", "-c", "exec uinput -"), null, null) as Process
            proc = p
            out = p.outputStream
            thread { try { p.errorStream.bufferedReader().forEachLine { log = it } } catch (_: Exception) {} }
            thread { try { p.inputStream.bufferedReader().forEachLine { log = it } } catch (_: Exception) {} }
            send(register(symbolic = variant == 0))
            Thread.sleep(1200)
            val alive = try { p.exitValue(); false } catch (e: Exception) { true }
            if (alive) {
                status = "Manette virtuelle créée ✔ (format ${variant + 1})"
            } else if (variant == 0) {
                begin(1)
            } else {
                status = "Échec de la création de la manette"
            }
        } catch (e: Throwable) {
            status = "Erreur : ${e.message}"
        }
    }

    fun stop() {
        try { out?.close() } catch (_: Exception) {}
        try { proc?.destroy() } catch (_: Exception) {}
        out = null
        proc = null
    }

    private fun send(json: String) {
        ex.execute {
            try {
                out?.write((json + "\n").toByteArray())
                out?.flush()
            } catch (e: Exception) {
                status = "Écriture impossible : ${e.message}"
            }
        }
    }

    fun button(id: String, down: Boolean) {
        val c = codes[id] ?: return
        send("""{"id":1,"command":"inject","events":[1,$c,${if (down) 1 else 0},0,0,0]}""")
    }

    /** dx, dy dans {-1,0,1} (dy = -1 : haut). Envoie la croix (hat) ET le stick gauche. */
    fun dir(dx: Int, dy: Int) {
        send("""{"id":1,"command":"inject","events":[3,16,$dx,3,17,$dy,3,0,${dx * 127},3,1,${dy * 127},0,0,0]}""")
    }

    private fun register(symbolic: Boolean): String {
        fun n(name: String, num: Int) = if (symbolic) "\"$name\"" else "$num"
        fun info(name: String, num: Int, mn: Int, mx: Int, flat: Int) =
            """{"code":${n(name, num)},"info":{"value":0,"minimum":$mn,"maximum":$mx,"fuzz":0,"flat":$flat,"resolution":0}}"""
        val ev = listOf(n("EV_KEY", 1), n("EV_ABS", 3), n("EV_SYN", 0)).joinToString(",")
        val keys = listOf(n("BTN_SOUTH", 304), n("BTN_EAST", 305), n("BTN_NORTH", 307), n("BTN_WEST", 308)).joinToString(",")
        val abs = listOf(n("ABS_X", 0), n("ABS_Y", 1), n("ABS_HAT0X", 16), n("ABS_HAT0Y", 17)).joinToString(",")
        val infos = listOf(
            info("ABS_X", 0, -127, 127, 8), info("ABS_Y", 1, -127, 127, 8),
            info("ABS_HAT0X", 16, -1, 1, 0), info("ABS_HAT0Y", 17, -1, 1, 0)
        ).joinToString(",")
        return """{"id":1,"command":"register","name":"Pad Virtuel","vid":4660,"pid":22136,"bus":"usb","configuration":[{"type":"UI_SET_EVBIT","data":[$ev]},{"type":"UI_SET_KEYBIT","data":[$keys]},{"type":"UI_SET_ABSBIT","data":[$abs]}],"abs_info":[$infos]}"""
    }
}
