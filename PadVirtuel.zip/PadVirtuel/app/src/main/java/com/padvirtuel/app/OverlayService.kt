package com.padvirtuel.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.Icon
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat

class OverlayService : Service() {

    companion object {
        @Volatile var instance: OverlayService? = null
        private const val CH = "pad"
        private const val ACTION_TOGGLE = "pad.toggle"
        private const val ACTION_EDIT = "pad.edit"
        private const val ACTION_QUIT = "pad.quit"

        fun start(c: Context) {
            ContextCompat.startForegroundService(c, Intent(c, OverlayService::class.java))
        }
    }

    private lateinit var wm: WindowManager
    private val views = LinkedHashMap<String, PadView>()
    private val lps = HashMap<String, WindowManager.LayoutParams>()
    private var shown = true
    var editing = false
        private set

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        instance = this
        Prefs.init(this)
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CH, "Pad Virtuel", NotificationManager.IMPORTANCE_LOW))
        ServiceCompat.startForeground(
            this, 1, notif(),
            if (Build.VERSION.SDK_INT >= 34) ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE else 0
        )
        if (!Settings.canDrawOverlays(this)) {
            stopSelf()
            return
        }
        buildViews()
        UinputPad.start()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_TOGGLE -> setShown(!shown)
            ACTION_EDIT -> toggleEdit()
            ACTION_QUIT -> stopSelf()
        }
        return START_NOT_STICKY
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        relayoutAll()
    }

    override fun onDestroy() {
        instance = null
        views.values.forEach { it.releaseAll(); try { wm.removeView(it) } catch (_: Exception) {} }
        views.clear()
        UinputPad.stop()
        super.onDestroy()
    }

    // ---------- Fenêtres ----------

    private fun buildViews() {
        val colors = mapOf(
            "dpad" to Color.WHITE,
            "a" to 0xFF5EE08A.toInt(), "b" to 0xFFFF6B6B.toInt(),
            "x" to 0xFF5BA8FF.toInt(), "y" to 0xFFFFD166.toInt()
        )
        for (id in Prefs.ids) {
            val v = PadView(this, id, id.uppercase(), colors[id] ?: Color.WHITE)
            if (id == "dpad") v.onDir = { dx, dy -> UinputPad.dir(dx, dy) }
            else v.onButton = { d -> UinputPad.button(id, d) }
            v.onDrag = { cx, cy -> moveTo(id, cx, cy) }
            val lp = WindowManager.LayoutParams(
                100, 100,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT
            )
            lp.gravity = Gravity.TOP or Gravity.START
            lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            views[id] = v
            lps[id] = lp
            fillParams(id)
            wm.addView(v, lp)
        }
    }

    private fun screen(): Pair<Int, Int> {
        if (Build.VERSION.SDK_INT >= 30) {
            val b = wm.maximumWindowMetrics.bounds
            return Pair(b.width(), b.height())
        }
        val dm = DisplayMetrics()
        @Suppress("DEPRECATION")
        wm.defaultDisplay.getRealMetrics(dm)
        return Pair(dm.widthPixels, dm.heightPixels)
    }

    private fun fillParams(id: String) {
        val (w, h) = screen()
        val v = views[id] ?: return
        val lp = lps[id] ?: return
        val size = (Prefs.base(id) * minOf(w, h) * Prefs.scale(id)).toInt().coerceAtLeast(60)
        lp.width = size
        lp.height = size
        lp.x = (Prefs.x(id) * w - size / 2f).toInt()
        lp.y = (Prefs.y(id) * h - size / 2f).toInt()
        val vis = Prefs.visible(id)
        v.visibility = if (shown && (vis || editing)) View.VISIBLE else View.GONE
        v.alpha = if (editing && !vis) 0.35f else Prefs.opacity
        v.editing = editing
        v.invalidate()
    }

    private fun layout(id: String) {
        fillParams(id)
        val v = views[id] ?: return
        val lp = lps[id] ?: return
        try { wm.updateViewLayout(v, lp) } catch (_: Exception) {}
    }

    fun relayoutAll() {
        views.keys.toList().forEach { layout(it) }
    }

    private fun moveTo(id: String, cx: Float, cy: Float) {
        val (w, h) = screen()
        Prefs.setPos(id, (cx / w).coerceIn(0.02f, 0.98f), (cy / h).coerceIn(0.03f, 0.97f))
        layout(id)
    }

    // ---------- États ----------

    private fun setShown(b: Boolean) {
        shown = b
        views.values.forEach { it.releaseAll() }
        relayoutAll()
        refreshNotif()
    }

    fun toggleEdit() {
        editing = !editing
        views.values.forEach { it.releaseAll() }
        relayoutAll()
        refreshNotif()
    }

    // ---------- Notification (toucher pour afficher/masquer) ----------

    private fun refreshNotif() {
        getSystemService(NotificationManager::class.java).notify(1, notif())
    }

    private fun notif(): Notification {
        fun pi(action: String, code: Int) = PendingIntent.getService(
            this, code, Intent(this, OverlayService::class.java).setAction(action),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        fun act(label: String, p: PendingIntent) =
            Notification.Action.Builder(Icon.createWithResource(this, R.drawable.ic_pad), label, p).build()

        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        return Notification.Builder(this, CH)
            .setSmallIcon(R.drawable.ic_pad)
            .setContentTitle("Pad Virtuel")
            .setContentText(if (editing) "Mode édition : glisse les touches" else if (shown) "Manette affichée" else "Manette masquée")
            .setContentIntent(open)
            .setOngoing(true)
            .addAction(act(if (shown) "Masquer" else "Afficher", pi(ACTION_TOGGLE, 1)))
            .addAction(act(if (editing) "Terminer" else "Éditer", pi(ACTION_EDIT, 2)))
            .addAction(act("Quitter", pi(ACTION_QUIT, 3)))
            .build()
    }
}
