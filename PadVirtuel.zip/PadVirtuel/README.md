# Pad Virtuel

Manette tactile affichée par-dessus ton jeu. Elle crée une vraie manette virtuelle (uinput) via Shizuku.

## Compiler
1. Android Studio > Open > dossier PadVirtuel > attendre la synchro Gradle
2. Build > Build APK(s) > installer l'APK sur le téléphone

## Utiliser
1. Installer **Shizuku** (Play Store ou GitHub) et le démarrer
   (Options développeur > Débogage sans fil > depuis l'app Shizuku : "Démarrer via le débogage sans fil").
   À refaire après chaque redémarrage du téléphone.
2. Ouvrir Pad Virtuel : autoriser l'affichage par-dessus, autoriser Shizuku.
3. "Démarrer la manette" (une notif apparaît : Masquer / Éditer / Quitter).
4. Lancer le jeu. Le pad s'affiche par-dessus.

## Godot
Dans Projet > Paramètres > Input Map, vérifie que tes actions ont bien les boutons A/B/X/Y
ET la croix directionnelle (D-pad) ou le stick gauche. Le pad envoie la croix ET le stick gauche.
